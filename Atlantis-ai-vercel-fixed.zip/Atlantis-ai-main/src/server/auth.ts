import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { db, UserRecord } from './db';

// Password hashing utilities
export function hashPassword(password: string): { hash: string; salt: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 310000, 64, 'sha512').toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const iterations = 310000;
  const verifyHash = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha512').toString('hex');
  // Timing-safe comparison; legacy 1,000-iteration hashes are migrated on successful login.
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(verifyHash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function verifyLegacyPassword(password: string, hash: string, salt: string): boolean {
  const legacyHash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(legacyHash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// Extend Express Request
export interface AuthenticatedRequest extends Request {
  user?: UserRecord;
}

// Authentication Middleware
export function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Authentication token required.' });
  }

  const session = db.findSessionByToken(token);
  if (!session) {
    return res.status(401).json({ error: 'Session invalid or expired. Please sign in again.' });
  }

  const user = db.findUserById(session.userId);
  if (!user) {
    return res.status(401).json({ error: 'User account not found.' });
  }

  req.user = db.checkAndRefreshUserQuota(user);
  next();
}

// Optional authentication: attach a valid user when present, but never silently
// create/use a shared guest account. Public endpoints must opt into guest access
// explicitly through /api/auth/guest.
export function optionalAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;

  if (token) {
    const session = db.findSessionByToken(token);
    if (session) {
      const user = db.findUserById(session.userId);
      if (user) req.user = db.checkAndRefreshUserQuota(user);
    }
  }
  next();
}
